create view flight_passengers as
select `utopia`.`flight_bookings`.`flight_id`  AS `flight_id`,
       `utopia`.`flight_bookings`.`booking_id` AS `booking_id`,
       `utopia`.`passenger`.`id`               AS `passenger_id`
from ((`utopia`.`flight_bookings` join `utopia`.`passenger` on ((`utopia`.`flight_bookings`.`booking_id` =
                                                                 `utopia`.`passenger`.`booking_id`)))
         join `utopia`.`booking` on ((`utopia`.`flight_bookings`.`booking_id` = `utopia`.`booking`.`id`)))
where (`utopia`.`booking`.`is_active` = true);

